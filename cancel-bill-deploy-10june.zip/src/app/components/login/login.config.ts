export const userData: Object = {
    'admin': {
        'password': 'admin',
        'role': 'admin'
    },
};
