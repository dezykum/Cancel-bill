import { ItemHighlighterDirective } from './item-highlighter.directive';

describe('ItemHighlighterDirective', () => {
  it('should create an instance', () => {
    const directive = new ItemHighlighterDirective();
    expect(directive).toBeTruthy();
  });
});
