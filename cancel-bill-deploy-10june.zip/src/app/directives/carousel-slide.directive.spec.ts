import { CarouselSlideDirective } from './carousel-slide.directive';

describe('CarouselSlideDirective', () => {
  it('should create an instance', () => {
    const directive = new CarouselSlideDirective();
    expect(directive).toBeTruthy();
  });
});
